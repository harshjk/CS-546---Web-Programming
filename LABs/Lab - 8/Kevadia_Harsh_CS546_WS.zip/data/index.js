/******************************************
 *  Author : Harsh Jagdishbhai Kevadia   
 *  Created On : Mon Jul 17 2017
 *  File : index.js
 *******************************************/
const palindrome = require("./palindrome");

module.exports = {
    palindrome: palindrome
};