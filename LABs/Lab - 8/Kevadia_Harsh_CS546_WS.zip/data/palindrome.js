/******************************************
 *  Author : Harsh Jagdishbhai Kevadia   
 *  Created On : Mon Jul 17 2017
 *  File : palindrome.js
 *******************************************/
let exportedMethods = {
    isPalindrome(text) {
        if (typeof text !== "string") throw "Must provide a string";
        
        return "Harsh Kevadia";
    }
}

module.exports = exportedMethods;