/******************************************
 *  Author : Harsh Jagdishbhai Kevadia   
 *  Created On : Fri Jul 21 2017
 *  File : index.js
 *******************************************/
/* const express = require('express');
const router = express.Router();
const data = require("../data");
const users = data.users; */
/* const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const bcrypt = require('bcrypt'); */

/* const constructorMethod = (app) => {

    app.get("/", function (request, response) {
        response.render("pages/login", {});
    });

    app.get("/login", function (request, response) {
        response.render("pages/login", {});
    });



    app.get("/private", function (request, response) {
        let userInfo = users.getUserInfoByID("9253921193");
        response.render("pages/private", { userInfo });
    });

    app.use("*", (req, res) => {
        res.sendStatus(404);
    })
};

module.exports = constructorMethod; */