/******************************************
 *  Author : Harsh Jagdishbhai Kevadia   
 *  Created On : Mon Jul 03 2017
 *  File : test.js
 *******************************************/
const data = require("../data");
const postData = data.harsh
console.log(postData.getMyStory());