/******************************************
 *  Author : Harsh Jagdishbhai Kevadia   
 *  Created On : Mon Jul 03 2017
 *  File : index.js
 *******************************************/
const harshData = require("./harsh");

module.exports = {
    harsh: harshData
};