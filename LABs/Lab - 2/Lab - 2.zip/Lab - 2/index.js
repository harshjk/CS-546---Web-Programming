/**
 * Created by Harsh Kevadia on 5/31/2017.
 */
const printShape = require("./printShape");
printShape.triangle(1);
printShape.triangle(10);
//printShape.rhombus(1);
printShape.rhombus(2);
printShape.rhombus(100);
//printShape.rhombus(3);
//printShape.square(1);
printShape.square(2);
printShape.square(10);
printShape.square(100);