/******************************************
 *  Author : Harsh Jagdishbhai Kevadia   
 *  Created On : Tue Jul 11 2017
 *  File : index.js
 *******************************************/
const recipesData = require("./recipes");

module.exports = {
    recipes: recipesData
};